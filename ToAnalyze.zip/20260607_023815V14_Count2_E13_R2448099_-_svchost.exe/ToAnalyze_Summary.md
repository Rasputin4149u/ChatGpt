﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260607_023815V14
ComputerName: RASPUTIN_U
EventCount: 2
FolderName: 20260607_023815V14_Count2_E13_R2448099_-_svchost.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260607_023815V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260607_023815V14.txt

## Event 1
EventID: 13
RecordID: 2448099
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event01_E13_R2448099_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event01_E13_R2448099_-_svchost.exe\RawEventXml_Record_2448099.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event01_E13_R2448099_-_svchost.exe\ProcessGuidTimeline_Record_2448099.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event01_E13_R2448099_-_svchost.exe\NearbyRecordWindow_Record_2448099.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event01_E13_R2448099_-_svchost.exe\FileEvidence_Record_2448099.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event01_E13_R2448099_-_svchost.exe\AutorunMatches_Record_2448099.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 2
EventID: 13
RecordID: 2448098
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event02_E13_R2448098_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event02_E13_R2448098_-_svchost.exe\RawEventXml_Record_2448098.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event02_E13_R2448098_-_svchost.exe\ProcessGuidTimeline_Record_2448098.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event02_E13_R2448098_-_svchost.exe\NearbyRecordWindow_Record_2448098.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event02_E13_R2448098_-_svchost.exe\FileEvidence_Record_2448098.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023815V14_Count2_E13_R2448099_-_svchost.exe\Event02_E13_R2448098_-_svchost.exe\AutorunMatches_Record_2448098.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

