﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260609_065330V14
ComputerName: RASPUTIN_U
EventCount: 1
FolderName: 20260609_065330V14_Count1_E13_R2488764_T1122_firefox.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_065330V14_Count1_E13_R2488764_T1122_firefox.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260609_065330V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260609_065330V14.txt

## Event 1
EventID: 13
RecordID: 2488764
ProcessGuid: {808de0cc-3c16-6a27-2825-00000000a600}
Image: Z:\InsPro\Browsers\Firefox\FirefoxPortable\App\Firefox64\firefox.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_065330V14_Count1_E13_R2488764_T1122_firefox.exe\Event01_E13_R2488764_T1122_firefox.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_065330V14_Count1_E13_R2488764_T1122_firefox.exe\Event01_E13_R2488764_T1122_firefox.exe\RawEventXml_Record_2488764.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_065330V14_Count1_E13_R2488764_T1122_firefox.exe\Event01_E13_R2488764_T1122_firefox.exe\ProcessGuidTimeline_Record_2488764.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_065330V14_Count1_E13_R2488764_T1122_firefox.exe\Event01_E13_R2488764_T1122_firefox.exe\NearbyRecordWindow_Record_2488764.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_065330V14_Count1_E13_R2488764_T1122_firefox.exe\Event01_E13_R2488764_T1122_firefox.exe\FileEvidence_Record_2488764.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_065330V14_Count1_E13_R2488764_T1122_firefox.exe\Event01_E13_R2488764_T1122_firefox.exe\AutorunMatches_Record_2488764.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 6

