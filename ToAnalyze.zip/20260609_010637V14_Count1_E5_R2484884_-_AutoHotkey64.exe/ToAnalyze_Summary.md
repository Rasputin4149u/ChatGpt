﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260609_010637V14
ComputerName: RASPUTIN_U
EventCount: 1
FolderName: 20260609_010637V14_Count1_E5_R2484884_-_AutoHotkey64.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_010637V14_Count1_E5_R2484884_-_AutoHotkey64.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260609_010637V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260609_010637V14.txt

## Event 1
EventID: 5
RecordID: 2484884
ProcessGuid: {808de0cc-e0ec-6a25-c71f-00000000a600}
Image: C:\Users\RASPUTIN4149\AppData\Local\Programs\AutoHotkey\v2\AutoHotkey64.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_010637V14_Count1_E5_R2484884_-_AutoHotkey64.exe\Event01_E5_R2484884_-_AutoHotkey64.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_010637V14_Count1_E5_R2484884_-_AutoHotkey64.exe\Event01_E5_R2484884_-_AutoHotkey64.exe\RawEventXml_Record_2484884.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_010637V14_Count1_E5_R2484884_-_AutoHotkey64.exe\Event01_E5_R2484884_-_AutoHotkey64.exe\ProcessGuidTimeline_Record_2484884.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_010637V14_Count1_E5_R2484884_-_AutoHotkey64.exe\Event01_E5_R2484884_-_AutoHotkey64.exe\NearbyRecordWindow_Record_2484884.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_010637V14_Count1_E5_R2484884_-_AutoHotkey64.exe\Event01_E5_R2484884_-_AutoHotkey64.exe\FileEvidence_Record_2484884.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260609_010637V14_Count1_E5_R2484884_-_AutoHotkey64.exe\Event01_E5_R2484884_-_AutoHotkey64.exe\AutorunMatches_Record_2484884.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

