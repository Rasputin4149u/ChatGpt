﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260608_124439V14
ComputerName: RASPUTIN_U
EventCount: 1
FolderName: 20260608_124439V14_Count1_E11_R2480886_EXE_WaaSMedicAgent.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_124439V14_Count1_E11_R2480886_EXE_WaaSMedicAgent.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260608_124439V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260608_124439V14.txt

## Event 1
EventID: 11
RecordID: 2480886
ProcessGuid: {808de0cc-8ee6-6a26-e022-00000000a600}
Image: C:\Windows\uus\AMD64\WaaSMedicAgent.exe
TargetFilename: C:\Windows\SystemTemp\euw2ED0.tmp.exe
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_124439V14_Count1_E11_R2480886_EXE_WaaSMedicAgent.exe\Event01_E11_R2480886_EXE_WaaSMedicAgent.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_124439V14_Count1_E11_R2480886_EXE_WaaSMedicAgent.exe\Event01_E11_R2480886_EXE_WaaSMedicAgent.exe\RawEventXml_Record_2480886.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_124439V14_Count1_E11_R2480886_EXE_WaaSMedicAgent.exe\Event01_E11_R2480886_EXE_WaaSMedicAgent.exe\ProcessGuidTimeline_Record_2480886.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_124439V14_Count1_E11_R2480886_EXE_WaaSMedicAgent.exe\Event01_E11_R2480886_EXE_WaaSMedicAgent.exe\NearbyRecordWindow_Record_2480886.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_124439V14_Count1_E11_R2480886_EXE_WaaSMedicAgent.exe\Event01_E11_R2480886_EXE_WaaSMedicAgent.exe\FileEvidence_Record_2480886.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_124439V14_Count1_E11_R2480886_EXE_WaaSMedicAgent.exe\Event01_E11_R2480886_EXE_WaaSMedicAgent.exe\AutorunMatches_Record_2480886.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

