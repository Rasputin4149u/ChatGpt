﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260607_071524V14
ComputerName: RASPUTIN_U
EventCount: 1
FolderName: 20260607_071524V14_Count1_E5_R2450691_-_AutoHotkey64.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_071524V14_Count1_E5_R2450691_-_AutoHotkey64.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260607_071524V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260607_071524V14.txt

## Event 1
EventID: 5
RecordID: 2450691
ProcessGuid: {808de0cc-8bd6-6a23-2f0f-00000000a600}
Image: C:\Users\RASPUTIN4149\AppData\Local\Programs\AutoHotkey\v2\AutoHotkey64.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_071524V14_Count1_E5_R2450691_-_AutoHotkey64.exe\Event01_E5_R2450691_-_AutoHotkey64.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_071524V14_Count1_E5_R2450691_-_AutoHotkey64.exe\Event01_E5_R2450691_-_AutoHotkey64.exe\RawEventXml_Record_2450691.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_071524V14_Count1_E5_R2450691_-_AutoHotkey64.exe\Event01_E5_R2450691_-_AutoHotkey64.exe\ProcessGuidTimeline_Record_2450691.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_071524V14_Count1_E5_R2450691_-_AutoHotkey64.exe\Event01_E5_R2450691_-_AutoHotkey64.exe\NearbyRecordWindow_Record_2450691.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_071524V14_Count1_E5_R2450691_-_AutoHotkey64.exe\Event01_E5_R2450691_-_AutoHotkey64.exe\FileEvidence_Record_2450691.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_071524V14_Count1_E5_R2450691_-_AutoHotkey64.exe\Event01_E5_R2450691_-_AutoHotkey64.exe\AutorunMatches_Record_2450691.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

