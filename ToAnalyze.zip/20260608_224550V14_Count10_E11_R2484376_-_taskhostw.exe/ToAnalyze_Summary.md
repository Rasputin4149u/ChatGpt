﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260608_224550V14
ComputerName: RASPUTIN_U
EventCount: 10
FolderName: 20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260608_224550V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260608_224550V14.txt

## Event 1
EventID: 11
RecordID: 2484376
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\TS_WERQueue.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event01_E11_R2484376_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event01_E11_R2484376_-_taskhostw.exe\RawEventXml_Record_2484376.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event01_E11_R2484376_-_taskhostw.exe\ProcessGuidTimeline_Record_2484376.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event01_E11_R2484376_-_taskhostw.exe\NearbyRecordWindow_Record_2484376.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event01_E11_R2484376_-_taskhostw.exe\FileEvidence_Record_2484376.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event01_E11_R2484376_-_taskhostw.exe\AutorunMatches_Record_2484376.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 2
EventID: 11
RecordID: 2484375
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\TS_InaccurateSystemTime.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event02_E11_R2484375_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event02_E11_R2484375_-_taskhostw.exe\RawEventXml_Record_2484375.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event02_E11_R2484375_-_taskhostw.exe\ProcessGuidTimeline_Record_2484375.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event02_E11_R2484375_-_taskhostw.exe\NearbyRecordWindow_Record_2484375.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event02_E11_R2484375_-_taskhostw.exe\FileEvidence_Record_2484375.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event02_E11_R2484375_-_taskhostw.exe\AutorunMatches_Record_2484375.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 3
EventID: 11
RecordID: 2484374
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\TS_DiagnosticHistory.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event03_E11_R2484374_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event03_E11_R2484374_-_taskhostw.exe\RawEventXml_Record_2484374.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event03_E11_R2484374_-_taskhostw.exe\ProcessGuidTimeline_Record_2484374.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event03_E11_R2484374_-_taskhostw.exe\NearbyRecordWindow_Record_2484374.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event03_E11_R2484374_-_taskhostw.exe\FileEvidence_Record_2484374.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event03_E11_R2484374_-_taskhostw.exe\AutorunMatches_Record_2484374.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 4
EventID: 11
RecordID: 2484373
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\RS_UserWERQueue.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event04_E11_R2484373_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event04_E11_R2484373_-_taskhostw.exe\RawEventXml_Record_2484373.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event04_E11_R2484373_-_taskhostw.exe\ProcessGuidTimeline_Record_2484373.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event04_E11_R2484373_-_taskhostw.exe\NearbyRecordWindow_Record_2484373.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event04_E11_R2484373_-_taskhostw.exe\FileEvidence_Record_2484373.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event04_E11_R2484373_-_taskhostw.exe\AutorunMatches_Record_2484373.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 5
EventID: 11
RecordID: 2484372
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\RS_UserDiagnosticHistory.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event05_E11_R2484372_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event05_E11_R2484372_-_taskhostw.exe\RawEventXml_Record_2484372.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event05_E11_R2484372_-_taskhostw.exe\ProcessGuidTimeline_Record_2484372.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event05_E11_R2484372_-_taskhostw.exe\NearbyRecordWindow_Record_2484372.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event05_E11_R2484372_-_taskhostw.exe\FileEvidence_Record_2484372.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event05_E11_R2484372_-_taskhostw.exe\AutorunMatches_Record_2484372.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 6
EventID: 11
RecordID: 2484371
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\RS_SyncSystemTime.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event06_E11_R2484371_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event06_E11_R2484371_-_taskhostw.exe\RawEventXml_Record_2484371.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event06_E11_R2484371_-_taskhostw.exe\ProcessGuidTimeline_Record_2484371.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event06_E11_R2484371_-_taskhostw.exe\NearbyRecordWindow_Record_2484371.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event06_E11_R2484371_-_taskhostw.exe\FileEvidence_Record_2484371.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event06_E11_R2484371_-_taskhostw.exe\AutorunMatches_Record_2484371.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 7
EventID: 11
RecordID: 2484370
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\RS_MachineWERQueue.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event07_E11_R2484370_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event07_E11_R2484370_-_taskhostw.exe\RawEventXml_Record_2484370.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event07_E11_R2484370_-_taskhostw.exe\ProcessGuidTimeline_Record_2484370.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event07_E11_R2484370_-_taskhostw.exe\NearbyRecordWindow_Record_2484370.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event07_E11_R2484370_-_taskhostw.exe\FileEvidence_Record_2484370.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event07_E11_R2484370_-_taskhostw.exe\AutorunMatches_Record_2484370.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 8
EventID: 11
RecordID: 2484369
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\RS_AdminDiagnosticHistory.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event08_E11_R2484369_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event08_E11_R2484369_-_taskhostw.exe\RawEventXml_Record_2484369.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event08_E11_R2484369_-_taskhostw.exe\ProcessGuidTimeline_Record_2484369.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event08_E11_R2484369_-_taskhostw.exe\NearbyRecordWindow_Record_2484369.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event08_E11_R2484369_-_taskhostw.exe\FileEvidence_Record_2484369.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event08_E11_R2484369_-_taskhostw.exe\AutorunMatches_Record_2484369.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 9
EventID: 11
RecordID: 2484368
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\DiagPackage.dll
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event09_E11_R2484368_DLL_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event09_E11_R2484368_DLL_taskhostw.exe\RawEventXml_Record_2484368.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event09_E11_R2484368_DLL_taskhostw.exe\ProcessGuidTimeline_Record_2484368.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event09_E11_R2484368_DLL_taskhostw.exe\NearbyRecordWindow_Record_2484368.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event09_E11_R2484368_DLL_taskhostw.exe\FileEvidence_Record_2484368.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event09_E11_R2484368_DLL_taskhostw.exe\AutorunMatches_Record_2484368.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 10
EventID: 11
RecordID: 2484367
ProcessGuid: {808de0cc-1b87-6a27-9924-00000000a600}
Image: C:\Windows\system32\taskhostw.exe
TargetFilename: C:\Windows\Temp\SDIAG_14f5e319-4abc-4c77-bd43-e9cb0bc012b5\CL_Utility.ps1
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event10_E11_R2484367_-_taskhostw.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event10_E11_R2484367_-_taskhostw.exe\RawEventXml_Record_2484367.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event10_E11_R2484367_-_taskhostw.exe\ProcessGuidTimeline_Record_2484367.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event10_E11_R2484367_-_taskhostw.exe\NearbyRecordWindow_Record_2484367.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event10_E11_R2484367_-_taskhostw.exe\FileEvidence_Record_2484367.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_224550V14_Count10_E11_R2484376_-_taskhostw.exe\Event10_E11_R2484367_-_taskhostw.exe\AutorunMatches_Record_2484367.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

