﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260607_025451V14
ComputerName: RASPUTIN_U
EventCount: 1
FolderName: 20260607_025451V14_Count1_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_025451V14_Count1_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260607_025451V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260607_025451V14.txt

## Event 1
EventID: 24
RecordID: 2448316
ProcessGuid: {808de0cc-072a-6a22-2306-00000000a600}
Image: Z:\InsPro\notepadP\notepad++.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_025451V14_Count1_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_025451V14_Count1_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\RawEventXml_Record_2448316.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_025451V14_Count1_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\ProcessGuidTimeline_Record_2448316.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_025451V14_Count1_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\NearbyRecordWindow_Record_2448316.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_025451V14_Count1_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\FileEvidence_Record_2448316.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_025451V14_Count1_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2448316_Track_My_SSD_Clipboard_Actions_notepad++.exe\AutorunMatches_Record_2448316.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

