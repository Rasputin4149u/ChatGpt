﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260607_023141V14
ComputerName: RASPUTIN_U
EventCount: 8
FolderName: 20260607_023141V14_Count8_E13_R2448084_-_svchost.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260607_023141V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260607_023141V14.txt

## Event 1
EventID: 13
RecordID: 2448084
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event01_E13_R2448084_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event01_E13_R2448084_-_svchost.exe\RawEventXml_Record_2448084.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event01_E13_R2448084_-_svchost.exe\ProcessGuidTimeline_Record_2448084.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event01_E13_R2448084_-_svchost.exe\NearbyRecordWindow_Record_2448084.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event01_E13_R2448084_-_svchost.exe\FileEvidence_Record_2448084.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event01_E13_R2448084_-_svchost.exe\AutorunMatches_Record_2448084.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 2
EventID: 13
RecordID: 2448083
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event02_E13_R2448083_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event02_E13_R2448083_-_svchost.exe\RawEventXml_Record_2448083.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event02_E13_R2448083_-_svchost.exe\ProcessGuidTimeline_Record_2448083.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event02_E13_R2448083_-_svchost.exe\NearbyRecordWindow_Record_2448083.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event02_E13_R2448083_-_svchost.exe\FileEvidence_Record_2448083.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event02_E13_R2448083_-_svchost.exe\AutorunMatches_Record_2448083.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 3
EventID: 13
RecordID: 2448082
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event03_E13_R2448082_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event03_E13_R2448082_-_svchost.exe\RawEventXml_Record_2448082.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event03_E13_R2448082_-_svchost.exe\ProcessGuidTimeline_Record_2448082.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event03_E13_R2448082_-_svchost.exe\NearbyRecordWindow_Record_2448082.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event03_E13_R2448082_-_svchost.exe\FileEvidence_Record_2448082.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event03_E13_R2448082_-_svchost.exe\AutorunMatches_Record_2448082.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 4
EventID: 13
RecordID: 2448054
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event04_E13_R2448054_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event04_E13_R2448054_-_svchost.exe\RawEventXml_Record_2448054.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event04_E13_R2448054_-_svchost.exe\ProcessGuidTimeline_Record_2448054.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event04_E13_R2448054_-_svchost.exe\NearbyRecordWindow_Record_2448054.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event04_E13_R2448054_-_svchost.exe\FileEvidence_Record_2448054.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event04_E13_R2448054_-_svchost.exe\AutorunMatches_Record_2448054.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 5
EventID: 13
RecordID: 2448053
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event05_E13_R2448053_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event05_E13_R2448053_-_svchost.exe\RawEventXml_Record_2448053.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event05_E13_R2448053_-_svchost.exe\ProcessGuidTimeline_Record_2448053.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event05_E13_R2448053_-_svchost.exe\NearbyRecordWindow_Record_2448053.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event05_E13_R2448053_-_svchost.exe\FileEvidence_Record_2448053.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event05_E13_R2448053_-_svchost.exe\AutorunMatches_Record_2448053.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 6
EventID: 13
RecordID: 2448044
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event06_E13_R2448044_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event06_E13_R2448044_-_svchost.exe\RawEventXml_Record_2448044.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event06_E13_R2448044_-_svchost.exe\ProcessGuidTimeline_Record_2448044.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event06_E13_R2448044_-_svchost.exe\NearbyRecordWindow_Record_2448044.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event06_E13_R2448044_-_svchost.exe\FileEvidence_Record_2448044.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event06_E13_R2448044_-_svchost.exe\AutorunMatches_Record_2448044.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 7
EventID: 13
RecordID: 2448043
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event07_E13_R2448043_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event07_E13_R2448043_-_svchost.exe\RawEventXml_Record_2448043.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event07_E13_R2448043_-_svchost.exe\ProcessGuidTimeline_Record_2448043.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event07_E13_R2448043_-_svchost.exe\NearbyRecordWindow_Record_2448043.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event07_E13_R2448043_-_svchost.exe\FileEvidence_Record_2448043.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event07_E13_R2448043_-_svchost.exe\AutorunMatches_Record_2448043.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 8
EventID: 13
RecordID: 2448042
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event08_E13_R2448042_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event08_E13_R2448042_-_svchost.exe\RawEventXml_Record_2448042.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event08_E13_R2448042_-_svchost.exe\ProcessGuidTimeline_Record_2448042.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event08_E13_R2448042_-_svchost.exe\NearbyRecordWindow_Record_2448042.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event08_E13_R2448042_-_svchost.exe\FileEvidence_Record_2448042.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_023141V14_Count8_E13_R2448084_-_svchost.exe\Event08_E13_R2448042_-_svchost.exe\AutorunMatches_Record_2448042.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

