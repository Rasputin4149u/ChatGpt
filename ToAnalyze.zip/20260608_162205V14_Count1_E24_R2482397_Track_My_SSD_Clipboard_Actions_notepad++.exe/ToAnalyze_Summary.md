﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260608_162205V14
ComputerName: RASPUTIN_U
EventCount: 1
FolderName: 20260608_162205V14_Count1_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_162205V14_Count1_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260608_162205V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260608_162205V14.txt

## Event 1
EventID: 24
RecordID: 2482397
ProcessGuid: {808de0cc-bee6-6a26-9523-00000000a600}
Image: Z:\InsPro\notepadP\notepad++.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_162205V14_Count1_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_162205V14_Count1_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\RawEventXml_Record_2482397.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_162205V14_Count1_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\ProcessGuidTimeline_Record_2482397.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_162205V14_Count1_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\NearbyRecordWindow_Record_2482397.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_162205V14_Count1_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\FileEvidence_Record_2482397.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_162205V14_Count1_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2482397_Track_My_SSD_Clipboard_Actions_notepad++.exe\AutorunMatches_Record_2482397.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

