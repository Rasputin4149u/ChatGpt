﻿# Same ProcessGuid timeline
$Guid = "{808de0cc-83c3-6a27-5f26-00000000a600}"
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" |
Where-Object { $_.Message -match [regex]::Escape($Guid) } |
Sort-Object TimeCreated |
Select-Object TimeCreated, Id, RecordId, ProviderName, Message |
Format-List

# Nearby RecordID window
$RecordId = 2487766
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" |
Where-Object { $_.RecordId -ge ($RecordId - 20) -and $_.RecordId -le ($RecordId + 20) } |
Sort-Object RecordId |
Select-Object TimeCreated, Id, RecordId, ProviderName, Message |
Format-List
