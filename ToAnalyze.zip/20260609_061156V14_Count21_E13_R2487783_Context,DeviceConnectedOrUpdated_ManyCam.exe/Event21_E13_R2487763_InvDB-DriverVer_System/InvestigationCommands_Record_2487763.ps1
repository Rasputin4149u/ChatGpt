﻿# Same ProcessGuid timeline
$Guid = "{808de0cc-9d3c-6a21-eb03-000000000000}"
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" |
Where-Object { $_.Message -match [regex]::Escape($Guid) } |
Sort-Object TimeCreated |
Select-Object TimeCreated, Id, RecordId, ProviderName, Message |
Format-List

# Nearby RecordID window
$RecordId = 2487763
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" |
Where-Object { $_.RecordId -ge ($RecordId - 20) -and $_.RecordId -le ($RecordId + 20) } |
Sort-Object RecordId |
Select-Object TimeCreated, Id, RecordId, ProviderName, Message |
Format-List
