﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260607_084708V14
ComputerName: RASPUTIN_U
EventCount: 5
FolderName: 20260607_084708V14_Count5_E13_R2452130_-_svchost.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260607_084708V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260607_084708V14.txt

## Event 1
EventID: 13
RecordID: 2452130
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event01_E13_R2452130_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event01_E13_R2452130_-_svchost.exe\RawEventXml_Record_2452130.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event01_E13_R2452130_-_svchost.exe\ProcessGuidTimeline_Record_2452130.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event01_E13_R2452130_-_svchost.exe\NearbyRecordWindow_Record_2452130.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event01_E13_R2452130_-_svchost.exe\FileEvidence_Record_2452130.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event01_E13_R2452130_-_svchost.exe\AutorunMatches_Record_2452130.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 2
EventID: 13
RecordID: 2452129
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event02_E13_R2452129_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event02_E13_R2452129_-_svchost.exe\RawEventXml_Record_2452129.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event02_E13_R2452129_-_svchost.exe\ProcessGuidTimeline_Record_2452129.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event02_E13_R2452129_-_svchost.exe\NearbyRecordWindow_Record_2452129.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event02_E13_R2452129_-_svchost.exe\FileEvidence_Record_2452129.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event02_E13_R2452129_-_svchost.exe\AutorunMatches_Record_2452129.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 3
EventID: 13
RecordID: 2452124
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event03_E13_R2452124_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event03_E13_R2452124_-_svchost.exe\RawEventXml_Record_2452124.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event03_E13_R2452124_-_svchost.exe\ProcessGuidTimeline_Record_2452124.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event03_E13_R2452124_-_svchost.exe\NearbyRecordWindow_Record_2452124.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event03_E13_R2452124_-_svchost.exe\FileEvidence_Record_2452124.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event03_E13_R2452124_-_svchost.exe\AutorunMatches_Record_2452124.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 4
EventID: 13
RecordID: 2452123
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event04_E13_R2452123_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event04_E13_R2452123_-_svchost.exe\RawEventXml_Record_2452123.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event04_E13_R2452123_-_svchost.exe\ProcessGuidTimeline_Record_2452123.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event04_E13_R2452123_-_svchost.exe\NearbyRecordWindow_Record_2452123.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event04_E13_R2452123_-_svchost.exe\FileEvidence_Record_2452123.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event04_E13_R2452123_-_svchost.exe\AutorunMatches_Record_2452123.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 5
EventID: 13
RecordID: 2452122
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event05_E13_R2452122_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event05_E13_R2452122_-_svchost.exe\RawEventXml_Record_2452122.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event05_E13_R2452122_-_svchost.exe\ProcessGuidTimeline_Record_2452122.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event05_E13_R2452122_-_svchost.exe\NearbyRecordWindow_Record_2452122.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event05_E13_R2452122_-_svchost.exe\FileEvidence_Record_2452122.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_084708V14_Count5_E13_R2452130_-_svchost.exe\Event05_E13_R2452122_-_svchost.exe\AutorunMatches_Record_2452122.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

