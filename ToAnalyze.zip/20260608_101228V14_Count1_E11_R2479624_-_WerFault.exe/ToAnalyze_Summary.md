﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260608_101228V14
ComputerName: RASPUTIN_U
EventCount: 1
FolderName: 20260608_101228V14_Count1_E11_R2479624_-_WerFault.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_101228V14_Count1_E11_R2479624_-_WerFault.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260608_101228V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260608_101228V14.txt

## Event 1
EventID: 11
RecordID: 2479624
ProcessGuid: {808de0cc-6ac1-6a26-2e22-00000000a600}
Image: C:\Windows\system32\WerFault.exe
TargetFilename: C:\ProgramData\Microsoft\Windows\WER\Temp\WER.fa5184ff-5863-40e3-b08c-75d0da575d1e.tmp.dmp
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_101228V14_Count1_E11_R2479624_-_WerFault.exe\Event01_E11_R2479624_-_WerFault.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_101228V14_Count1_E11_R2479624_-_WerFault.exe\Event01_E11_R2479624_-_WerFault.exe\RawEventXml_Record_2479624.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_101228V14_Count1_E11_R2479624_-_WerFault.exe\Event01_E11_R2479624_-_WerFault.exe\ProcessGuidTimeline_Record_2479624.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_101228V14_Count1_E11_R2479624_-_WerFault.exe\Event01_E11_R2479624_-_WerFault.exe\NearbyRecordWindow_Record_2479624.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_101228V14_Count1_E11_R2479624_-_WerFault.exe\Event01_E11_R2479624_-_WerFault.exe\FileEvidence_Record_2479624.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260608_101228V14_Count1_E11_R2479624_-_WerFault.exe\Event01_E11_R2479624_-_WerFault.exe\AutorunMatches_Record_2479624.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

