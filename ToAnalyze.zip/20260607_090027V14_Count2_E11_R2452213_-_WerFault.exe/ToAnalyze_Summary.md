﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260607_090027V14
ComputerName: RASPUTIN_U
EventCount: 2
FolderName: 20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260607_090027V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260607_090027V14.txt

## Event 1
EventID: 11
RecordID: 2452213
ProcessGuid: {808de0cc-07fc-6a25-cc1a-00000000a600}
Image: C:\Windows\system32\WerFault.exe
TargetFilename: C:\ProgramData\Microsoft\Windows\WER\Temp\WER.73f794a2-59dc-4146-b1a0-edc125de88e5.tmp.dmp
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event01_E11_R2452213_-_WerFault.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event01_E11_R2452213_-_WerFault.exe\RawEventXml_Record_2452213.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event01_E11_R2452213_-_WerFault.exe\ProcessGuidTimeline_Record_2452213.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event01_E11_R2452213_-_WerFault.exe\NearbyRecordWindow_Record_2452213.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event01_E11_R2452213_-_WerFault.exe\FileEvidence_Record_2452213.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event01_E11_R2452213_-_WerFault.exe\AutorunMatches_Record_2452213.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 2
EventID: 11
RecordID: 2452211
ProcessGuid: {808de0cc-07e9-6a25-c81a-00000000a600}
Image: C:\Windows\system32\WerFault.exe
TargetFilename: C:\ProgramData\Microsoft\Windows\WER\Temp\WER.78db0cad-335e-4860-b560-66845caae156.tmp.dmp
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event02_E11_R2452211_-_WerFault.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event02_E11_R2452211_-_WerFault.exe\RawEventXml_Record_2452211.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event02_E11_R2452211_-_WerFault.exe\ProcessGuidTimeline_Record_2452211.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event02_E11_R2452211_-_WerFault.exe\NearbyRecordWindow_Record_2452211.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event02_E11_R2452211_-_WerFault.exe\FileEvidence_Record_2452211.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_090027V14_Count2_E11_R2452213_-_WerFault.exe\Event02_E11_R2452211_-_WerFault.exe\AutorunMatches_Record_2452211.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

