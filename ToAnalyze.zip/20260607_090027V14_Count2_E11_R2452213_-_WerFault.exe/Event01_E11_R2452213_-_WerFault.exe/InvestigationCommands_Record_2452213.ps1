﻿# Same ProcessGuid timeline
$Guid = "{808de0cc-07fc-6a25-cc1a-00000000a600}"
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" |
Where-Object { $_.Message -match [regex]::Escape($Guid) } |
Sort-Object TimeCreated |
Select-Object TimeCreated, Id, RecordId, ProviderName, Message |
Format-List

# Nearby RecordID window
$RecordId = 2452213
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" |
Where-Object { $_.RecordId -ge ($RecordId - 20) -and $_.RecordId -le ($RecordId + 20) } |
Sort-Object RecordId |
Select-Object TimeCreated, Id, RecordId, ProviderName, Message |
Format-List
