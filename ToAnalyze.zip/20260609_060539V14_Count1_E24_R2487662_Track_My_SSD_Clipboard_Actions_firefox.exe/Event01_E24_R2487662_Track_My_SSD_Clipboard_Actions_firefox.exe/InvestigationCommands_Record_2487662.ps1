﻿# Same ProcessGuid timeline
$Guid = "{808de0cc-3c2d-6a27-4425-00000000a600}"
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" |
Where-Object { $_.Message -match [regex]::Escape($Guid) } |
Sort-Object TimeCreated |
Select-Object TimeCreated, Id, RecordId, ProviderName, Message |
Format-List

# Nearby RecordID window
$RecordId = 2487662
Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" |
Where-Object { $_.RecordId -ge ($RecordId - 20) -and $_.RecordId -le ($RecordId + 20) } |
Sort-Object RecordId |
Select-Object TimeCreated, Id, RecordId, ProviderName, Message |
Format-List
