﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260607_082303V14
ComputerName: RASPUTIN_U
EventCount: 10
FolderName: 20260607_082303V14_Count10_E13_R2451631_-_svchost.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260607_082303V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260607_082303V14.txt

## Event 1
EventID: 13
RecordID: 2451631
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event01_E13_R2451631_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event01_E13_R2451631_-_svchost.exe\RawEventXml_Record_2451631.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event01_E13_R2451631_-_svchost.exe\ProcessGuidTimeline_Record_2451631.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event01_E13_R2451631_-_svchost.exe\NearbyRecordWindow_Record_2451631.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event01_E13_R2451631_-_svchost.exe\FileEvidence_Record_2451631.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event01_E13_R2451631_-_svchost.exe\AutorunMatches_Record_2451631.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 2
EventID: 13
RecordID: 2451630
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event02_E13_R2451630_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event02_E13_R2451630_-_svchost.exe\RawEventXml_Record_2451630.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event02_E13_R2451630_-_svchost.exe\ProcessGuidTimeline_Record_2451630.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event02_E13_R2451630_-_svchost.exe\NearbyRecordWindow_Record_2451630.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event02_E13_R2451630_-_svchost.exe\FileEvidence_Record_2451630.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event02_E13_R2451630_-_svchost.exe\AutorunMatches_Record_2451630.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 3
EventID: 13
RecordID: 2451627
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event03_E13_R2451627_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event03_E13_R2451627_-_svchost.exe\RawEventXml_Record_2451627.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event03_E13_R2451627_-_svchost.exe\ProcessGuidTimeline_Record_2451627.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event03_E13_R2451627_-_svchost.exe\NearbyRecordWindow_Record_2451627.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event03_E13_R2451627_-_svchost.exe\FileEvidence_Record_2451627.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event03_E13_R2451627_-_svchost.exe\AutorunMatches_Record_2451627.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 4
EventID: 13
RecordID: 2451626
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event04_E13_R2451626_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event04_E13_R2451626_-_svchost.exe\RawEventXml_Record_2451626.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event04_E13_R2451626_-_svchost.exe\ProcessGuidTimeline_Record_2451626.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event04_E13_R2451626_-_svchost.exe\NearbyRecordWindow_Record_2451626.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event04_E13_R2451626_-_svchost.exe\FileEvidence_Record_2451626.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event04_E13_R2451626_-_svchost.exe\AutorunMatches_Record_2451626.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 5
EventID: 13
RecordID: 2451625
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event05_E13_R2451625_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event05_E13_R2451625_-_svchost.exe\RawEventXml_Record_2451625.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event05_E13_R2451625_-_svchost.exe\ProcessGuidTimeline_Record_2451625.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event05_E13_R2451625_-_svchost.exe\NearbyRecordWindow_Record_2451625.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event05_E13_R2451625_-_svchost.exe\FileEvidence_Record_2451625.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event05_E13_R2451625_-_svchost.exe\AutorunMatches_Record_2451625.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 6
EventID: 13
RecordID: 2451618
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event06_E13_R2451618_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event06_E13_R2451618_-_svchost.exe\RawEventXml_Record_2451618.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event06_E13_R2451618_-_svchost.exe\ProcessGuidTimeline_Record_2451618.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event06_E13_R2451618_-_svchost.exe\NearbyRecordWindow_Record_2451618.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event06_E13_R2451618_-_svchost.exe\FileEvidence_Record_2451618.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event06_E13_R2451618_-_svchost.exe\AutorunMatches_Record_2451618.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 7
EventID: 13
RecordID: 2451617
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event07_E13_R2451617_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event07_E13_R2451617_-_svchost.exe\RawEventXml_Record_2451617.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event07_E13_R2451617_-_svchost.exe\ProcessGuidTimeline_Record_2451617.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event07_E13_R2451617_-_svchost.exe\NearbyRecordWindow_Record_2451617.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event07_E13_R2451617_-_svchost.exe\FileEvidence_Record_2451617.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event07_E13_R2451617_-_svchost.exe\AutorunMatches_Record_2451617.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 8
EventID: 13
RecordID: 2451605
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event08_E13_R2451605_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event08_E13_R2451605_-_svchost.exe\RawEventXml_Record_2451605.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event08_E13_R2451605_-_svchost.exe\ProcessGuidTimeline_Record_2451605.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event08_E13_R2451605_-_svchost.exe\NearbyRecordWindow_Record_2451605.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event08_E13_R2451605_-_svchost.exe\FileEvidence_Record_2451605.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event08_E13_R2451605_-_svchost.exe\AutorunMatches_Record_2451605.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 9
EventID: 13
RecordID: 2451604
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event09_E13_R2451604_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event09_E13_R2451604_-_svchost.exe\RawEventXml_Record_2451604.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event09_E13_R2451604_-_svchost.exe\ProcessGuidTimeline_Record_2451604.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event09_E13_R2451604_-_svchost.exe\NearbyRecordWindow_Record_2451604.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event09_E13_R2451604_-_svchost.exe\FileEvidence_Record_2451604.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event09_E13_R2451604_-_svchost.exe\AutorunMatches_Record_2451604.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

## Event 10
EventID: 13
RecordID: 2451603
ProcessGuid: {808de0cc-9d46-6a21-6100-00000000a600}
Image: C:\Windows\system32\svchost.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event10_E13_R2451603_-_svchost.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event10_E13_R2451603_-_svchost.exe\RawEventXml_Record_2451603.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event10_E13_R2451603_-_svchost.exe\ProcessGuidTimeline_Record_2451603.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event10_E13_R2451603_-_svchost.exe\NearbyRecordWindow_Record_2451603.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event10_E13_R2451603_-_svchost.exe\FileEvidence_Record_2451603.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_082303V14_Count10_E13_R2451631_-_svchost.exe\Event10_E13_R2451603_-_svchost.exe\AutorunMatches_Record_2451603.txt
AutorunSearchStatus: MatchesFound
AutorunMatchCount: 520

