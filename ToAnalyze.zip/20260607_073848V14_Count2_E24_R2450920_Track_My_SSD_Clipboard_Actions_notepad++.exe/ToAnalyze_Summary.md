﻿# Sysmon ToAnalyze Evidence Pack

AlertTime: 20260607_073848V14
ComputerName: RASPUTIN_U
EventCount: 2
FolderName: 20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe
FolderPath: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe
AutoCsvFile: Z:\backup\Data\EventViewer\SysmonReal\Auto\AutoRun_20260607_073848V14.csv
AutoTxtFile: Z:\backup\Data\EventViewer\SysmonReal\txt\AutoRun_20260607_073848V14.txt

## Event 1
EventID: 24
RecordID: 2450920
ProcessGuid: {808de0cc-f07d-6a24-e219-00000000a600}
Image: Z:\InsPro\notepadP\notepad++.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\RawEventXml_Record_2450920.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\ProcessGuidTimeline_Record_2450920.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\NearbyRecordWindow_Record_2450920.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\FileEvidence_Record_2450920.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event01_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\AutorunMatches_Record_2450920.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

## Event 2
EventID: 24
RecordID: 2450913
ProcessGuid: {808de0cc-f07d-6a24-e219-00000000a600}
Image: Z:\InsPro\notepadP\notepad++.exe
TargetFilename: N/A
EventFolder: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event02_E24_R2450913_Track_My_SSD_Clipboard_Actions_notepad++.exe
RawEventXmlFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event02_E24_R2450913_Track_My_SSD_Clipboard_Actions_notepad++.exe\RawEventXml_Record_2450913.xml
ProcessGuidTimelineFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event02_E24_R2450913_Track_My_SSD_Clipboard_Actions_notepad++.exe\ProcessGuidTimeline_Record_2450913.txt
NearbyRecordWindowFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event02_E24_R2450913_Track_My_SSD_Clipboard_Actions_notepad++.exe\NearbyRecordWindow_Record_2450913.txt
FileEvidenceFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event02_E24_R2450913_Track_My_SSD_Clipboard_Actions_notepad++.exe\FileEvidence_Record_2450913.txt
AutorunMatchesFile: Z:\backup\Data\EventViewer\SysmonReal\ToAnalyze\20260607_073848V14_Count2_E24_R2450920_Track_My_SSD_Clipboard_Actions_notepad++.exe\Event02_E24_R2450913_Track_My_SSD_Clipboard_Actions_notepad++.exe\AutorunMatches_Record_2450913.txt
AutorunSearchStatus: NoMatches
AutorunMatchCount: 0

